package model;

/**  
* Abhishek Ryan - aryan9  
* CIS171 22149
* Apr 30, 2022  
*/
public class WirelessMouse {

	private int mouseId; //represents the laptop's id or item number as an integer
	private String name; //represents the name of the mouse as a string
	private String description; //represents the mouse's description
	private String color; //represents the mouse's color as a string
	private double price; //represents the mouse's price as a double
	private boolean hasWirelessMouse; //represents whether or not the mouse has been added to the user's cart
	
	//public default no-arg constructor initializes each instance variable
	public WirelessMouse() {
		this.mouseId = 0;
		this.name = "";
		this.description = "";
		this.color = ""; 
		this.price = 0.0;
		this.hasWirelessMouse = false;
	}
	
	//public non-default constructor has 5 parameters & sets the values for each instance variable
	public WirelessMouse(int mouseId, String name, String description, String color, double price) {
		this.mouseId = mouseId;
		this.name = name;
		this.description = description;
		this.color = color;
		this.price = price;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}
	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	
	/**
	 * @return the mouseId
	 */
	public int getMouseId() {
		return mouseId;
	}

	/**
	 * @param mouseId the mouseId to set
	 */
	public void setMouseId(int mouseId) {
		this.mouseId = mouseId;
	}
	
	/**
	 * @return the hasWirelessMouse
	 */
	public boolean isHasWirelessMouse() {
		return hasWirelessMouse;
	}

	/**
	 * @param hasWirelessMouse the hasWirelessMouse to set
	 */
	public void setHasWirelessMouse(boolean hasWirelessMouse) {
		this.hasWirelessMouse = hasWirelessMouse;
	}

	//public ToString() method of return type String is used to call the values for every instance variable and returns them in a properly formatted string
	public String ToString() {
		return "\nItem Number: " + getMouseId() + "\nName: " + getName() + "\nDescription - " + getDescription() + "\nColor: " + getColor() + 
				"\nPrice: $" + getPrice();
	}
	
}
