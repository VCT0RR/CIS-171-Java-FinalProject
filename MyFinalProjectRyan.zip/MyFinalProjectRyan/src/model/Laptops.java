package model;

/**  
* Abhishek Ryan - aryan9  
* CIS171 22149
* Apr 30, 2022  
*/
public class Laptops {

	private int laptopId; //represents the laptop's id or item number as an integer
	private String name; //represents the name of the laptop as a string
	private String description; //represents the laptop's cpu, gpu, ram, system storage size and type, and laptop brand model/series as a string
	private String color; //represents the laptop's color as a string
	private double price; //represents the laptop's price as a double
	
	//public default no-arg constructor initializes each instance variable
	public Laptops() {
		this.laptopId = 0;
		this.name = "";
		this.description = "";
		this.color = ""; 
		this.price = 0.0;
	}
	
	//public non-default constructor only has one parameter and is called into the LaptopPanel class
	public Laptops(int laptopId) {
		super();
		this.laptopId = laptopId;
	}
	
	//public non-default constructor has 5 parameters & sets the values for each instance variable
	public Laptops(int laptopId, String name, String description, String color, double price) {
		this.laptopId = laptopId;
		this.name = name;
		this.description = description;
		this.color = color;
		this.price = price;
	}
	
	/**
	 * @return the laptopId
	 */
	public int getLaptopId() {
		return laptopId;
	}

	/**
	 * @param laptopId the laptopId to set
	 */
	public void setLaptopId(int laptopId) {
		this.laptopId = laptopId;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}
	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	
	//public ToString() method of return type string returns the values for each instance variable in a properly formatted string text
	public String ToString() {
		return "\nItem Number: " + getLaptopId() + "\nName: " + getName() + "\nDescription: " + getDescription() + "\nColor: " + getColor() + "\nPrice: $" + getPrice();
	}
	
	/**
	 * Method of return type double and takes one parameter
	 * Method calculates the shipping cost and tax cost based off their constant tax and shipping rates and adds it the the total purchase value
	 * @param items of data type double represents the total value of all the purchased items from the user that includes the laptop, mouse, and/or warranty
	 * Returns the total purchase for the user as a double 
	 */
	public double laptopPurchase(double items) {
		
		//2 constant double variables that each represent that constant rates for the tax and shipping
		final double TAX_RATE = 0.07;
		final double SHIPPING_RATE = 0.10;
		
		//3 double variables are declared and initialized to zero
		double itemsTax = 0.0;
		double shippingCost = 0.0; 
		double purchaseTotal = 0.0;
		
		itemsTax = TAX_RATE * items; //calculates the tax cost by multiplying the tax rate times the value of all the items from the user
		shippingCost = SHIPPING_RATE * items; //calculates the shipping cost by multiplying the shipping rate times the value of all the items from the user
		purchaseTotal = items + itemsTax + shippingCost; //the purchase total is calculated by adding the values of the items from the user plus the tax cost and shipping cost
		
		//if the total value of all the items are less than or equal to zero then it will return zero
		if(items <= 0) {
			return 0;
		}
		return purchaseTotal; //returns the total purchase as a double
	}
}
