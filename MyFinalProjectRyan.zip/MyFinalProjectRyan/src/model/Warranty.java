package model;

/**  
* Abhishek Ryan - aryan9  
* CIS171 22149
* Apr 30, 2022  
*/
public class Warranty {

	private String name; //represents the warranty's name
	private double price; //represents the warranty's price
	private boolean hasWarranty; //represents whether or not the warranty is added to the user's cart
	
	//public default no-arg constructor initializes each instance variable
	public Warranty() {
		this.name = "";
		this.price = 0.0;
		this.hasWarranty = false;
	}
	 
	//public non-default constructor has 2 parameters & sets the values for each instance variable
	public Warranty(String name, double price) {
		this.name = name;
		this.price = price;
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}
	/**
	 * @return the hasWarranty
	 */
	public boolean isHasWarranty() {
		return hasWarranty;
	}
	/**
	 * @param hasWarranty the hasWarranty to set
	 */
	public void setHasWarranty(boolean hasWarranty) {
		this.hasWarranty = hasWarranty;
	}
	
	//public ToString() method of return type String is used to call the values for the name & price fields and returns them in a properly formatted string
	public String ToString() {
		return "\nWarranty: " + getName() + "\nPrice: $" + getPrice();
	}
}
