package controller;


import java.awt.Image;

import javax.swing.*;

import javax.swing.JFrame;
import javax.swing.JPanel;

import view.LaptopPanel;

/**  
* Abhishek Ryan - aryan9  
* CIS171 22149
* May 2, 2022  
*/
public class StartProgram extends JFrame {

	public static void main(String[] args) {
		
		JFrame frame = new JFrame();
		JPanel panel = new LaptopPanel();	 
		
		ImageIcon gamingLaptops = new ImageIcon("gamingLaptops.jpg");
		JLabel picture = new JLabel(gamingLaptops);
		panel.add(picture);
		
		frame.add(panel);
		frame.setSize(350, 350);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);		
		
		
	}
}
