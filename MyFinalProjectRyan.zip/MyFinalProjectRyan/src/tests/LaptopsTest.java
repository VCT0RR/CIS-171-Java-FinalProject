package tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import model.Laptops;

/**  
* Abhishek Ryan - aryan9  
* CIS171 22149
* May 2, 2022  
*/
class LaptopsTest { 

	/**
	 * Test method for {@link model.Laptops#ToString()}.
	 */
	@Test
	void testToString() {
		
		Laptops laptop = new Laptops(); //new laptop object is created from the Laptops class
		String expected = "\nItem Number: 0\nName: \nDescription: \nColor: \nPrice: $0.0";
		assertEquals(expected, laptop.ToString());
	}

	/**
	 * Test method for {@link model.Laptops#laptopPurchase(double)}.
	 */
	@Test
	void testLaptopPurchase() {
		
		Laptops laptops = new Laptops(); //new laptops object is created from the Laptops class
		
		//asserts for only the base price of the laptop
	    assertEquals(1871.9883, laptops.laptopPurchase(1599.99), 0.01);
		assertEquals(935.9883, laptops.laptopPurchase(799.99), 0.01);
		assertEquals(1052.9883, laptops.laptopPurchase(899.99), 0.01);
		assertEquals(1813.4883, laptops.laptopPurchase(1549.99), 0.01);
		assertEquals(2690.9882, laptops.laptopPurchase(2299.99), 0.01);
		
		//asserts for both the added costs of the wireless mouse and the warranty
		assertEquals(2076.7149, laptops.laptopPurchase(1774.97), 0.01);
		assertEquals(1140.7149, laptops.laptopPurchase(974.97), 0.01);
		assertEquals(1257.7149, laptops.laptopPurchase(1074.97), 0.01);
		assertEquals(2018.2149, laptops.laptopPurchase(1724.97), 0.01);
		assertEquals(2895.7149, laptops.laptopPurchase(2474.97), 0.01);
		
		//asserts only with the added wireless mouse cost
		assertEquals(1959.7266, laptops.laptopPurchase(1674.98), 0.01);
		assertEquals(1023.7266, laptops.laptopPurchase(874.98), 0.01);
		assertEquals(1140.7266, laptops.laptopPurchase(974.98), 0.01);
		assertEquals(1901.2266, laptops.laptopPurchase(1624.98), 0.01);
		assertEquals(2778.7266, laptops.laptopPurchase(2374.98), 0.01);
		
		//asserts only with the added warranty cost
		assertEquals(1988.9766, laptops.laptopPurchase(1699.98), 0.01);
		assertEquals(1052.9766, laptops.laptopPurchase(899.98), 0.01);
		assertEquals(1169.9766, laptops.laptopPurchase(999.98), 0.01);
		assertEquals(1930.4766, laptops.laptopPurchase(1649.98), 0.01);
		assertEquals(2807.9766, laptops.laptopPurchase(2399.98), 0.01);
		
		assertEquals(0, laptops.laptopPurchase(-1), 0.01); //asserts for a negative value
	}

}
