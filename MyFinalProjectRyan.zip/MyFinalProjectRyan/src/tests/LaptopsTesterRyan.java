package tests;
import java.util.Scanner;

import model.Laptops;
import model.Warranty;
import model.WirelessMouse;
/**
 * Abhishek Ryan - aryan9 
 * CIS171 22149 
 * Apr 30, 2022
 */
public class LaptopsTesterRyan {

	public static void main(String[] args) {

		//try-catch block surrounds entire program code and is used to handle all exceptions for bad user input
		try {
		// creates a new Scanner object that allows the program to take in user input
		Scanner in = new Scanner(System.in); 
		
		String programExit = "y"; //variable is declared & initialized and represents the sentinel value that is used to end the program
		
		Laptops laptop = new Laptops(); //new laptop object is created from the Laptops class
		
		//5 new laptop objects are created from the Laptops class with all having 5 parameters
		Laptops laptop1 = new Laptops(90500,"ASUS - ROG Zephyrus 15.6\" QHD Gaming Laptop", 
				  						"AMD Ryzen 9 - 16GB Memory - NVIDIA GeForce RTX 3070 - 1TB SSD", "Eclispe 4Grey", 1599.99);
		Laptops laptop2 = new Laptops(90501, "MSI - GF65 15.6\" 144hz Gaming Laptop", 
				  						"Intel Core i5 - NVIDIA GeForce RTX3060 - 512GB SSD - 8GB Memory", "Black", 799.99);
		Laptops laptop3 = new Laptops(90502, "Dell - G15 15.6\" FHD Gaming Laptop",
				  						"AMD Ryzen 7 - 8GB Memory - NVIDIA GeForce RTX 3050 Ti Graphics - 512GB SSD", "Phantom Grey", 899.99);
		Laptops laptop4 = new Laptops(90503, "ASUS - ROG Zephyrus M16 GU603 Gaming Laptop", 
				  						"Intel Core i9 - 16GB Memory - NVIDIA RTX3060 - 1TB SSD", "Off Black", 1549.99);
		Laptops laptop5 = new Laptops(90504, "Razer - Blade 15 Advanced - 15.6\" Gaming Laptop", 
				  						"QHD- 240HZ - Intel Core i7 - NVIDIA GeForce RTX 3060 - 16GB RAM - 1TB SSD", "Black", 2299.99);
		
		//new mouse1 object is created from the WirelessMouse class and has 5 parameters
		WirelessMouse mouse1 = new WirelessMouse(30300, "Logitech G903 Lightspeed Wireless Gaming Mouse", 
													"Battery Life: 140 Hrs, Sensor: HERO 25k, Resolution: 100 - 25,600 dpi, Max Speed: >400 IPS", "Black", 89.99);
		
		Warranty warranty = new Warranty("2-Year Protection Plan", 99.99); //new warranty object is created from the Warranty class with 2 parameters

		// 4 prints statements that welcomes the user and explains the functionality of the program to the user
		System.out.println("Hello! Welcome to Abhishek's Laptop Purchasing Program!");
		System.out.println("\nHere you can purchase high-end gaming laptops.");
		System.out.println("You can choose any laptop from a total of 5 different laptops with various price points and specs.");
		System.out.println("Along with a laptop you'll have the option of buying a 2 year protection warranty and an optional wireless mouse.");

		// prints message that tells the user to enter a word that will display all of the laptops
		System.out.println("\nType 'display' to display all laptops: ");
		String displayLaptops = in.next().toLowerCase(); // takes and reads user input as a string and sets the input to lower case

		//while loop that loops continously if the user input does not equal 'display' & exits once the user enters the correct text
		while (!displayLaptops.equals("display")) {
			System.out.println("Invalid Input! Type 'display' to display all 5 laptops: "); // prints error message to the user for bad input
			displayLaptops = in.next().toLowerCase(); // takes and reads user input as a string and sets it to lowercase
		}
		
		//while loop that loops continuously as long as the user enters "y" at the end of the program if they want to purchase more laptops, otherwise the program ends
		while(programExit.equalsIgnoreCase("y")) {
		
			//5 print statements utilizes all 5 laptop objects to call the ToString() method from the Laptops class & display all the information for each laptop
			System.out.println("Laptops: ");
			System.out.println(laptop1.ToString());
			System.out.println(laptop2.ToString());
			System.out.println(laptop3.ToString());
			System.out.println(laptop4.ToString());
			System.out.println(laptop5.ToString());

			//prints message to the user and prompts them to enter the laptop's product number in order to purchase a laptop
			System.out.println("\nTo purchase a laptop enter its 5 digit item number: ");
			int laptopChoice = in.nextInt(); //takes & reads user input as an integer
			
			double runningTotal = 0.0; //variable of data type double is set to 0 & is used to keep a running total that keeps track of the user's purchases
					
			//if-else-if statement that tests if the laptopChoice from the user is equal to at least one of the 5 laptop item numbers
			//otherwise an error message is displayed to the user
			if(laptopChoice == laptop1.getLaptopId()) {
				System.out.println("Laptop 1 has been added to your cart."); //prints that the laptop has been added to their purchase
				runningTotal += laptop1.getPrice(); //the cost of the laptop is added to the runningTotal variable
			}else if(laptopChoice == laptop2.getLaptopId()) {
				System.out.println("Laptop 2 has been added to your cart."); //prints that the laptop has been added to their purchase
				runningTotal += laptop2.getPrice(); //the cost of the laptop is added to the runningTotal variable
			}else if(laptopChoice == laptop3.getLaptopId()) {
				System.out.println("Laptop 3 has been added to your cart."); //prints that the laptop has been added to their purchase
				runningTotal += laptop3.getPrice(); //the cost of the laptop is added to the runningTotal variable
			}else if(laptopChoice == laptop4.getLaptopId()) {
				System.out.println("Laptop 4 has been added to your cart."); //prints that the laptop has been added to their purchase
				runningTotal += laptop4.getPrice(); //the cost of the laptop is added to the runningTotal variable
			}else if(laptopChoice == laptop5.getLaptopId()) {
				System.out.println("Laptop 5 has been added to your cart."); //prints that the laptop has been added to their purchase
				runningTotal += laptop5.getPrice(); //the cost of the laptop is added to the runningTotal variable
			}
			else {
				System.out.println("Invalid Item Number!. To purchase a laptop enter its 5 digit item number: "); //prints error message to the user
				laptopChoice = in.nextInt(); //takes & reads user input as an integer
			}
			
			//print statement utilizes the mouse1 object to call the ToString() method from the WirelessMouse class & display all the information for the mouse
			System.out.println("\n\nWireless Mouse: ");
			System.out.println(mouse1.ToString());
			
			//prints message to the user and prompts them to enter either [y]es or [n]o in order to purchase a laptop mouse
			System.out.println("\nWould you like to add the optional wireless mouse to your cart?  [y]es or [n]o: ");
			String mouseChoice = in.next().toLowerCase(); //takes & reads user input as an integer
			
			//if the user enters "y", then the mouse is added to the user's cart/subtotal
			if(mouseChoice.equals("y")) {
				System.out.println("Wireless Mouse has been added to your cart."); //prints that the wireless mouse has been added to their purchase
				runningTotal += mouse1.getPrice(); //the cost of the wireless mouse is added to the runningTotal variable
				mouse1.setHasWirelessMouse(true); //sets the value of the wireless mouse to true if it is added to the user's cart
			}
			else {
				//wireless mouse is not added to the user's cart
				System.out.println("Wireless Mouse will not be added to your cart.");
				mouse1.setHasWirelessMouse(false); //sets the value of the wireless mouse to false if it is not added to the user's cart
			}
			
			//print statement utilizes the warranty object to call the ToString() method from the Warranty class & display all the information for the warranty
			System.out.println("\n\nWarranty: ");
			System.out.println(warranty.ToString());
			
			//asks the user if they would like to add the warranty to their cart/subtotal
			System.out.println("\nWould you like to add optional the 2-year warranty to your cart? [y]es or [n]o: ");
			String warrantyChoice = in.next().toLowerCase(); //takes and reads user input as a string and sets it to lowercase
			
			//if the user inputs "y" as their choice, then a message is displayed, otherwise the warranty is not added to the cart
			if(warrantyChoice.equals("y")) {
				System.out.println("Warranty has been added to your cart."); //tells the user that the warranty has been added to their cart
				runningTotal += warranty.getPrice(); //the cost of the warranty is added to the runningTotal variable
				warranty.setHasWarranty(true); //sets the value of the warranty to true if it is added to the user's cart
			}
			else {
				//warranty is not added to the total purchase for the user
				System.out.println("Warranty will not be added to your cart.");
				warranty.setHasWarranty(false); //sets the value of the warranty to false if it is not added to the user's cart
			}

			//prints a purchase summary or receipt to the user
			System.out.println("\nPurchase Summary:");
			System.out.println("*******************************************");
			System.out.println("Laptop Number: " + laptopChoice); //prints the laptop number that the user purchased
			
			//calls the isHasWirelessMouse() method from the WirelessMouse class & displays whether or not the user added the wireless mouse to their purchase
			System.out.println("Wireless Mouse Added: " + mouse1.isHasWirelessMouse());
			
			//calls the isHasWarranty() method from the Warranty class & displays whether or not the user added the warranty to their purchase
			System.out.println("Warrantey Added: " + warranty.isHasWarranty());
			
			//calls the laptopPurchase() method & prints the total cost that includes the tax & shipping costs & is formatted to 2 decimal places
			System.out.printf("Total (includes tax & shipping): $%.2f\n", laptop.laptopPurchase(runningTotal));
			System.out.println("*******************************************");
			
			System.out.println("\nWould you like to purchase another laptop? [y]es or [n]o: "); //prints message to the user asking if they want to continue
			programExit = in.next().toLowerCase(); //takes and reads user input as a string and sets the input to lower case
		}	
		//prints message to the user once the program has ended by entering the sentinel value
		System.out.println("\nYou have exited the program.");	
		in.close();
	}
		//catch statement catches & handles any exception that occurs from user input
		catch(Exception e) {
			System.out.println("Invalid Input! Please try again."); //prints error message to the user
		}
	}
}
