package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.Laptops;
import model.Warranty;
import model.WirelessMouse;
import view.LaptopPanel.ClearButtonListener;
import view.LaptopPanel.PurchaseLaptopButtonListener;

/**
 * Abhishek Ryan - 
 * aryan9 CIS171 22149 
 * May 2, 2022
 */
public class LaptopPanel extends JPanel {

	//new df object is created from the DecimalFormat class and is formatted to 2 decimal places for integer values
	DecimalFormat df = new DecimalFormat("###.00");

	//two JLabel titles are created from the JLabel class & are the main titles at the top of the store page/GUI
	private JLabel title = new JLabel("------- Gaming Laptop Store -------");
	private JLabel title2 = new JLabel("------- Welcome to Abhishek's Gaming Laptop Store! -------"); 

	//new label object is created from the JLabel class
	private JLabel viewLaptopsLabel = new JLabel("View Laptops: ");

	//5 laptop buttons are created from the JButton class & are initialized with the laptop brand names as the button labels
	private JButton laptop1Button = new JButton("ASUS");
	private JButton laptop2Button = new JButton("MSI");
	private JButton laptop3Button = new JButton("DELL");
	private JButton laptop4Button = new JButton("ASUS");
	private JButton laptop5Button = new JButton("RAZER");

	//purchaseLaptopButton object is created and is used to purchase the desired laptop when clicked
	private JButton purchaseLaptopButton = new JButton("Buy Laptop");
	
	//clearButton object is created and is used to clear all the entry fields when clicked
	private JButton clearButton = new JButton("Clear");

	//laptopLabel object is created from the JLabel class
	private JLabel laptopLabel = new JLabel("Enter the item number to add a laptop to your cart");
	
	//itemNumText object is created from the JLabel class
	private JLabel itemNumText = new JLabel("Enter Laptop Item#: ");
	
	//inputItemNumField object is created from the JTextField class, takes up to 5 text characters & is used to take in the laptop item number from the user
	private JTextField inputItemNumField = new JTextField(5);
	
	//itemNameText object is created from the JLabel class
	private JLabel itemNameText = new JLabel("-----------------Item Name: ");
	
	//itemNameField object is created from the JTextField class, takes up to 5 text characters & is used to display the name of the laptop
	private JTextField itemNameField = new JTextField(5);
	
	//itemCostText object is created from the JLabel class
	private JLabel itemCostText = new JLabel("-----------------Item Cost: ");
	
	//itemCostField object is created from the JTextField class, takes up to 5 text characters & is used to display the cost of the laptop
	private JTextField itemCostField = new JTextField(5);
	
	//public default no-arg constructor is created and is used to add all the objects from above to the JFrame
	public LaptopPanel() {
		super();

		//adds the two title labels to the frame
		add(title);
		add(title2);

		add(viewLaptopsLabel); //adds the viewLaptopsLabel to the frame

		//adds all 5 laptop buttons to the frame
		add(laptop1Button);
		add(laptop2Button);
		add(laptop3Button);
		add(laptop4Button);
		add(laptop5Button);

		add(laptopLabel); //adds the laptopLabel to the frame
		
		//adds the itemNum JLabel and JTextField to the frame
		add(itemNumText);
		add(inputItemNumField);
		
		add(purchaseLaptopButton); //adds the purchaseLaptopButton button to the frame
		
		//adds the itemName JLabel and JTextField to the frame
		add(itemNameText);
		add(itemNameField);
		
		//adds the itemCost JLabel and JTextField to the frame
		add(itemCostText);
		add(itemCostField);

		//new clearListener object is created from the inner ClearButtonListener class
		ClearButtonListener clearListener = new ClearButtonListener();
		clearButton.addActionListener(clearListener); //the clearListener object is added to the clearButton button
		
		//new laptopListener object is created from the inner PurchaseLaptopButtonListener class
		PurchaseLaptopButtonListener laptopListener = new PurchaseLaptopButtonListener();
		purchaseLaptopButton.addActionListener(laptopListener); //the laptopListener object is added to the purchaseLaptopButton button

		add(clearButton); //adds the clearButton button to the frame

		//the laptop1Button adds the laptop1 object to the button and displays all its information when clicked
		laptop1Button.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				//new laptop object is created from the Laptops class with 5 parameters
				Laptops laptop1 = new Laptops(90500, "ASUS - ROG Zephyrus 15.6\" QHD Gaming Laptop",
						"AMD Ryzen 9 - 16GB Memory - NVIDIA GeForce RTX 3070 - 1TB SSD", "Eclispe 4Grey", 1599.99);
				
				//the JOptionPane dialog box is used to call the ToString() method for the laptop1 object & displays all the laptop's info when clicked
				JOptionPane.showMessageDialog(laptop1Button, laptop1.ToString());
			}
		});

		
		//the laptop2Button adds the laptop2 object to the button and displays all its information when clicked
		laptop2Button.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				//new laptop object is created from the Laptops class with 5 parameters
				Laptops laptop2 = new Laptops(90500, "ASUS - ROG Zephyrus 15.6\" QHD Gaming Laptop",
						"AMD Ryzen 9 - 16GB Memory - NVIDIA GeForce RTX 3070 - 1TB SSD", "Eclispe 4Grey", 1599.99);
				
				//the JOptionPane dialog box is used to call the ToString() method for the laptop2 object & displays all the laptop's info when clicked
				JOptionPane.showMessageDialog(laptop2Button, laptop2.ToString());
			}
		});

		
		//the laptop3Button adds the laptop3 object to the button and displays all its information when clicked
		laptop3Button.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				//new laptop object is created from the Laptops class with 5 parameters
				Laptops laptop3 = new Laptops(90500, "ASUS - ROG Zephyrus 15.6\" QHD Gaming Laptop",
						"AMD Ryzen 9 - 16GB Memory - NVIDIA GeForce RTX 3070 - 1TB SSD", "Eclispe 4Grey", 1599.99);
				
				//the JOptionPane dialog box is used to call the ToString() method for the laptop3 object & displays all the laptop's info when clicked
				JOptionPane.showMessageDialog(laptop3Button, laptop3.ToString());
			}
		});

		
		//the laptop4Button adds the laptop4 object to the button and displays all its information when clicked
		laptop4Button.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				//new laptop object is created from the Laptops class with 5 parameters
				Laptops laptop4 = new Laptops(90500, "ASUS - ROG Zephyrus 15.6\" QHD Gaming Laptop",
						"AMD Ryzen 9 - 16GB Memory - NVIDIA GeForce RTX 3070 - 1TB SSD", "Eclispe 4Grey", 1599.99);
				
				//the JOptionPane dialog box is used to call the ToString() method for the laptop4 object & displays all the laptop's info when clicked
				JOptionPane.showMessageDialog(laptop4Button, laptop4.ToString());
			}
		});

		
		//the laptop5Button adds the laptop5 object to the button and displays all its information when clicked
		laptop5Button.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				//new laptop object is created from the Laptops class with 5 parameters
				Laptops laptop5 = new Laptops(90500, "ASUS - ROG Zephyrus 15.6\" QHD Gaming Laptop",
						"AMD Ryzen 9 - 16GB Memory - NVIDIA GeForce RTX 3070 - 1TB SSD", "Eclispe 4Grey", 1599.99);
				
				//the JOptionPane dialog box is used to call the ToString() method for the laptop5 object & displays all the laptop's info when clicked
				JOptionPane.showMessageDialog(laptop5Button, laptop5.ToString());
			}
		});
	}
	//inner class is created to purchase the desired laptop that is entered in by the user and implements the ActionListener
	class PurchaseLaptopButtonListener implements ActionListener {

		//public void method has one parameter and is used to take in user input and purchases & returns the item number and item cost for the desired laptop
		@Override
		public void actionPerformed(ActionEvent e) {

			//try-catch block is used to catch and handle any exception that occurs from bad user input
			try {
				//parses the user input as an Integer and stores the value into the laptopNumber field
				int laptopNumber = Integer.parseInt(inputItemNumField.getText());
				Laptops lp = new Laptops(laptopNumber); //creates new object from the Laptops class with one parameter
				
				itemNameField.setText(lp.getName()); //gets the name of the item/laptop
				itemCostField.setText(df.format(lp.getPrice())); //gets the price of the item/laptop and formats it to 2 decimal places
				
				} catch (NumberFormatException ex) {
					resetFields(); //resets all the fields if an exception is thrown
				}			
		}
	}
	//inner class is created to clear all text fields in the GUI by using the ActionListener
	class ClearButtonListener implements ActionListener {

		//public void method has one parameter and is used to clear all the fields in the GUI
		@Override
		public void actionPerformed(ActionEvent e) {
			inputItemNumField.setText("");
			itemNameField.setText("");
			itemCostField.setText("");
		}
	}
	//public void method is used to reset and clear all 3 item fields
	public void resetFields() {
		inputItemNumField.setText("");
		itemNameField.setText("");
		itemCostField.setText("");
	}
}
